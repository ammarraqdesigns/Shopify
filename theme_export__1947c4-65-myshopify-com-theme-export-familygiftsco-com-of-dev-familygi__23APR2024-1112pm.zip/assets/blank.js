// DO NOT REMOVE
// Used by the async scripts system
